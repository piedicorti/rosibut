import os
import time
import requests
from bs4 import BeautifulSoup
from telegram import Bot
from dotenv import load_dotenv

load_dotenv()

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
CHAT_ID = os.getenv("CHAT_ID")

bot = Bot(token=TELEGRAM_TOKEN)

def send_alert(match_name, minute, score, stats, confidence):
    message = f"🔔 Alerte but probable ({minute}e)\n" \
              f"{match_name} ({score})\n" \
              f"{stats}\n" \
              f"Confiance : {confidence} %"
    bot.send_message(chat_id=CHAT_ID, text=message)

def extract_live_matches():
    # TODO : remplacer par scraping Sofascore ou Flashscore
    return [{
        "match": "PSG - OM",
        "minute": 77,
        "score": "1-1",
        "stats": {
            "tirs_cadres": 6,
            "xg": 1.8,
            "possession": 62,
            "corners": 7,
            "dangerous_attacks_ratio": 2.2,
            "momentum": 75,
            "score_status": "draw"
        }
    }]

def evaluate_match(match):
    points = 0
    stats = match["stats"]
    if stats["tirs_cadres"] >= 5: points += 1
    if stats["xg"] > 1.5: points += 2
    if stats["possession"] > 60: points += 1
    if stats["corners"] >= 5: points += 1
    if stats["dangerous_attacks_ratio"] >= 2: points += 1
    if stats["momentum"] >= 70: points += 1
    if stats["score_status"] in ["draw", "losing"]: points += 1

    confidence = round((points / 7) * 100)

    if points >= 3:
        stats_str = f"Tirs cadrés : {stats['tirs_cadres']} | xG : {stats['xg']} | Corners : {stats['corners']}"
        send_alert(match["match"], match["minute"], match["score"], stats_str, confidence)

def main_loop():
    while True:
        try:
            matches = extract_live_matches()
            for match in matches:
                if 75 <= match["minute"] <= 90:
                    evaluate_match(match)
        except Exception as e:
            print("Erreur :", e)
        time.sleep(60)

if __name__ == "__main__":
    main_loop()